# 25.Dato je rastojanje u centimetrima između ulaza u dvije različite kancelarije.
# Odrediti koliko cijelih metara ima u tom rastojanju. Npr. 324cm imaju 3 metra.

cm = int(input("Unesi cm: "))
m = cm // 100
print(m)