#3. Napisati program koji racuna razliku kvadrata.

a = float(input('Unesi A '))
b = float(input('Unesi B '))

resenje = (a-b) * (a+b)
print(resenje)
