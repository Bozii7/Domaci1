#12. Kreirati algoritam koji računa koje godine je rođen Miloš ukoliko je poznato da danas ima
#N godina.

N = int(input("Unesi godine "))

god_rodjenja = 2024 - N

print(god_rodjenja)
