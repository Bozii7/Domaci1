#5. Napisati program koji na osnovu zadate širine i visine lista papira (pravougaonog oblika)
#u milimetrima određuje njegovu površinu u kvadratnim centimetrima.

d = int(input("Unesi duzinu "))
s = int(input("Unesi sirinu "))

p = d * s / 100
print(p)