'''
16. Ako je cijena taksija za jedan kilometar 0.5e, a početna cijena je 1e, napisati kod koji za
unijeti broj pređenih kilometara računa cijenu vožnje.
'''

km = int(input('Unesi broj km: '))
cijena = 1 + 0.5 * km
print(cijena)

