#4. Sportista se na početku treninga zagrijeva tako što trči po ivicama pravougaonog terena
#dužine d i širine s. Napisati program kojim se određuje koliko metara pretrči sportista dok
#obiđe teren 4 puta.

d = int(input("Unesi duzinu"))
s = int(input("Unesi sirinu"))

o = 2 * d + 2 * s

print(4 * o)