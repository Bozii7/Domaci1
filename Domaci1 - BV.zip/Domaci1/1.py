#1. Napisati program koji racuna površinu i obim pravougaonika.

a = int(input("Unesi duzinu "))
b = int(input("Unesi sirinu "))

p = a * b
o = 2 * a + 2 * b

print(p, o)